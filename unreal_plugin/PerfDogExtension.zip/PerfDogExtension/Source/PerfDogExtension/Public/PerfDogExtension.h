// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "HAL/Platform.h"
#include "HAL/Thread.h"
#include "HAL/CriticalSection.h"
#include "HAL/Runnable.h"
#include "Containers/Map.h"

static constexpr int32 MESSAGE_HEADER_LENGTH = 4;
static constexpr int32 MAX_MESSAGE_LENGTH = 4096;
static constexpr uint32 PROTOCOL_MAGIC_NUMBER = 'PDEX';
static constexpr uint32 PROTOCOL_VERSION = 1;

enum class EMessageType : uint16
{
	Invalid = 0,
	StartTestReq,
	StartTestRsp,
	StopTestReq,
	StopTestRsp,
	StringMap,
	CustomFloatValue,
	CustomIntegerValue,
	CustomStringValue,
	CleanMap,
	SetLabelReq,
	AddNoteReq,
	DeepMarkReq,
	DeepCounterReq,
	DeepPushReq,
	DeepPopReq
};

struct FProtocolHeader
{
	uint32 MagicNumber = PROTOCOL_MAGIC_NUMBER;
	uint32 Version = PROTOCOL_VERSION;
};

struct FMessageHeader
{
	uint16 Length;
	uint16 Type;
};

class FPerfDogBuffer
{
public:
	FPerfDogBuffer(uint8* Buffer, int32 Capacity);

	int32 GetDataSize() const { return Position; }
	int32 GetRemaining() const { return Capacity - Position; }
	bool IsOverflow() const { return bIsOverflow; }

	void WriteInt32(int32 Value);
	int32 ReadInt32();
	void WriteUint32(uint32 Value);
	uint32 ReadUint32();
	void WriteUint64(uint64 Value);
	uint64 ReadUint64();
	void WriteFloat(float Value);
	float ReadFloat();
	void WriteString(const FString& Value);
	void ReadString(FString& Value);
	void WriteBytes(const void* Data, uint32 Size);
	void ReadBytes(void* Data, uint32 Size);

private:
	uint8* Buffer;
	int32 Capacity;
	int32 Position;
	bool bIsOverflow;
};

class FPerfDogMessage
{
public:
	virtual ~FPerfDogMessage() = default;
	virtual EMessageType GetType() const = 0;
	virtual void Serialize(FPerfDogBuffer& Buffer) const = 0;
	virtual void Deserialize(FPerfDogBuffer& Buffer) = 0;
};

class FStringOrId
{
public:
	static constexpr uint32 InvalidStringId = 0xffffffff;

	FStringOrId();
	FStringOrId(uint32 Id);
	FStringOrId(const FString& String);
	FStringOrId(const FStringOrId& Other);
	FStringOrId(FStringOrId&& Other);
	FStringOrId& operator=(const FStringOrId& Other);
	FStringOrId& operator=(FStringOrId&& Other);

	bool IsId() const { return Id != InvalidStringId; }
	uint32 GetId() const { return Id; }
	const FString& GetString() const { return String; }

	void Serialize(FPerfDogBuffer& Buffer) const;
	void Deserialize(FPerfDogBuffer& Buffer);

private:
	uint32 Id;
	FString String;
};

class FStringMapMessage : public FPerfDogMessage
{
public:
	FStringMapMessage() = default;
	FStringMapMessage(uint32 Id, const FString& Name);

	EMessageType GetType() const override { return EMessageType::StringMap; }
	void Serialize(FPerfDogBuffer& Buffer) const override;
	void Deserialize(FPerfDogBuffer& Buffer) override;

	uint32 GetId() const { return Id; }
	const FString& GetName() const { return Name; }

private:
	uint32 Id;
	FString Name;
};

class FCustomValueMessage : public FPerfDogMessage
{
public:
	FCustomValueMessage() = default;
	FCustomValueMessage(uint64 Time, const FStringOrId& Category, const FStringOrId& KeyName);

	void Serialize(FPerfDogBuffer& Buffer) const override;
	void Deserialize(FPerfDogBuffer& Buffer) override;

	uint64 GetTime() const { return Time; }

protected:
	uint64 Time;
	FStringOrId Category;
	FStringOrId KeyName;
};

class FCustomFloatValueMessage : public FCustomValueMessage
{
public:
	FCustomFloatValueMessage() = default;
	FCustomFloatValueMessage(uint64 Time, const FStringOrId& Category, const FStringOrId& KeyName, const TArray<float>& Values);

	EMessageType GetType() const override { return EMessageType::CustomFloatValue; }
	void Serialize(FPerfDogBuffer& Buffer) const override;
	void Deserialize(FPerfDogBuffer& Buffer) override;

private:
	TArray<float> Values;
};

class FCustomIntegerValueMessage : public FCustomValueMessage
{
public:
	FCustomIntegerValueMessage() = default;
	FCustomIntegerValueMessage(uint64 Time, const FStringOrId& Category, const FStringOrId& KeyName, const TArray<int32>& Values);

	EMessageType GetType() const override { return EMessageType::CustomIntegerValue; }
	void Serialize(FPerfDogBuffer& Buffer) const override;
	void Deserialize(FPerfDogBuffer& Buffer) override;

private:
	TArray<int32> Values;
};

class FCustomStringValueMessage : public FCustomValueMessage
{
public:
	FCustomStringValueMessage() = default;
	FCustomStringValueMessage(uint64 Time, const FStringOrId& Category, const FStringOrId& KeyName, const FStringOrId& Value);

	EMessageType GetType() const override { return EMessageType::CustomStringValue; }
	void Serialize(FPerfDogBuffer& Buffer) const override;
	void Deserialize(FPerfDogBuffer& Buffer) override;

private:
	FStringOrId Value;
};

class FSetLabelReqMessage : public FPerfDogMessage
{
public:
	FSetLabelReqMessage() = default;
	FSetLabelReqMessage(uint64 Time, const FString& Name);

	EMessageType GetType() const override { return EMessageType::SetLabelReq; }
	void Serialize(FPerfDogBuffer& Buffer) const override;
	void Deserialize(FPerfDogBuffer& Buffer) override;

private:
	uint64 Time;
	FString Name;
};

class FAddNoteReqMessage : public FPerfDogMessage
{
public:
	FAddNoteReqMessage() = default;
	FAddNoteReqMessage(uint64 Time, const FString& Name);

	EMessageType GetType() const override { return EMessageType::AddNoteReq; }
	void Serialize(FPerfDogBuffer& Buffer) const override;
	void Deserialize(FPerfDogBuffer& Buffer) override;

private:
	uint64 Time;
	FString Name;
};

class FDeepMessage : public FPerfDogMessage
{
public:
	FDeepMessage() = default;
	FDeepMessage(uint64 Time, int32 ThreadId, const FStringOrId& Name);

	void Serialize(FPerfDogBuffer& Buffer) const override;
	void Deserialize(FPerfDogBuffer& Buffer) override;

protected:
	uint64 Time;
	int32 ThreadId;
	FStringOrId Name;
};

class FDeepMarkReqMessage : public FDeepMessage
{
public:
	FDeepMarkReqMessage() = default;
	FDeepMarkReqMessage(uint64 Time, int32 ThreadId, const FStringOrId& Name);

	EMessageType GetType() const override { return EMessageType::DeepMarkReq; }
};

class FDeepCounterReqMessage : public FPerfDogMessage
{
public:
	FDeepCounterReqMessage() = default;
	FDeepCounterReqMessage(uint64 Time, const FStringOrId& Name, float Value);

	EMessageType GetType() const override { return EMessageType::DeepCounterReq; }
	void Serialize(FPerfDogBuffer& Buffer) const override;
	void Deserialize(FPerfDogBuffer& Buffer) override;

private:
	uint64 Time;
	FStringOrId Name;
	float Value;
};

class FDeepPushReqMessage : public FDeepMessage
{
public:
	FDeepPushReqMessage() = default;
	FDeepPushReqMessage(uint64 Time, int32 ThreadId, const FStringOrId& Name);

	EMessageType GetType() const override { return EMessageType::DeepPushReq; }
};

class FDeepPopReqMessage : public FDeepMessage
{
public:
	FDeepPopReqMessage() = default;
	FDeepPopReqMessage(uint64 Time, int32 ThreadId, const FStringOrId& Name);

	EMessageType GetType() const override { return EMessageType::DeepPopReq; }
};

class FEmptyMessageWrapper : public FPerfDogMessage
{
public:
	FEmptyMessageWrapper(EMessageType Type);

	EMessageType GetType() const override { return MessageType; }
	void Serialize(FPerfDogBuffer& Buffer) const override {}
	void Deserialize(FPerfDogBuffer& Buffer) override {}

private:
	EMessageType MessageType;
};

struct FPerfDogBlock
{
	int32 Capacity;
	int32 Cursor;
	TArray<uint8> Data;

	FPerfDogBlock(int32 InCapacity);
	int32 Available() const { return Capacity - Cursor; }
};

using FPerfDogBlockPtr = TSharedPtr<FPerfDogBlock>;

class FPerfDogExtension;

class FPerfDogDataProcessingRunnable : public FRunnable
{
public:
	FPerfDogDataProcessingRunnable(FPerfDogExtension* InExtension) : Extension(InExtension) {}

	virtual bool Init() override { return true; }
	virtual uint32 Run() override;
	virtual void Exit() override {}

private:
	FPerfDogExtension* Extension;
};

class FPerfDogExtension : public FRunnable
{
	friend class FPerfDogDataProcessingRunnable;

public:
	FPerfDogExtension();
	virtual ~FPerfDogExtension();

	int32 Initialize();

	void PostValueF(const FString& Category, const FString& Key, float Value);
	void PostValueF(const FString& Category, const FString& Key, float Value1, float Value2);
	void PostValueF(const FString& Category, const FString& Key, float Value1, float Value2, float Value3);
	void PostValueI(const FString& Category, const FString& Key, int32 Value);
	void PostValueI(const FString& Category, const FString& Key, int32 Value1, int32 Value2);
	void PostValueI(const FString& Category, const FString& Key, int32 Value1, int32 Value2, int32 Value3);
	void PostValueS(const FString& Category, const FString& Key, const FString& Value);
	void SetLabel(const FString& Name);
	void AddNote(const FString& Name);
	void DeepMark(const FString& Name);
	void DeepCounter(const FString& Name, float Value);
	void DeepPush(const FString& Name);
	void DeepPop(const FString& Name);
	bool IsStartTest() const { return bStartTest; }

	virtual bool Init() override;
	virtual uint32 Run() override;
	virtual void Stop() override;
	virtual void Exit() override;

protected:
	void OnConnect();
	void OnMessage(uint16 Type, const FPerfDogMessage* Message);
	void OnDisconnect();

	int32 StartServer();
	void StopServer();
	int32 SendData(const void* Buffer, int32 Size);
	void ErrorLog(const TCHAR* Format, ...);
	uint64 CurrentTime();
	int32 CurrentThreadId();
	void NetworkThread();
	void ProcessClientData();
	int32 ReadWithTimeout(int32 TimeoutMs, uint8* Buffer, int32 Count);

private:
	void StartTest();
	void StopTest();
	void ClearData();
	int32 WriteData(const void* Buffer, int32 Size);
	void WriteMessage(const FPerfDogMessage& Message);
	FStringOrId StringToId(const FString& String);
	void SendStreamHeader();
	void StartDataProcessingThread();
	void StopDataProcessingThread();
	void DrainBuffer();

protected:
	bool bInitialized;
	int32 InitializeResult;
	mutable FCriticalSection StateLock;
	bool bStartTest;
	bool bShouldStop;
	bool bStopDrainBuffer;

	FCriticalSection BufferLock;
	TArray<FPerfDogBlockPtr> BlockList;  // 前插链表 prependant linked list

	FCriticalSection StringMapLock;
	TMap<FString, uint32> StringToIdMap;
	uint32 NextStringId;

	FRunnableThread* DataProcessingThreadPtr;
	FPerfDogDataProcessingRunnable* DataProcessingRunnable;

	class FSocket* ServerSocket;
	class FSocket* ClientSocket;
	FRunnableThread* NetworkThreadPtr;
#if PLATFORM_MAC || PLATFORM_IOS
	uint64 TimeFrequency;
#endif
};


class FPerfDogExtensionModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	static FPerfDogExtensionModule& Get();

	static int32 EnablePerfDogExtension();
	static bool IsTestStarted();
	static void PostFloatValue(const FString& Category, const FString& Key, float Value);
	static void PostFloatValue(const FString& Category, const FString& Key, float Value1, float Value2);
	static void PostFloatValue(const FString& Category, const FString& Key, float Value1, float Value2, float Value3);
	static void PostIntValue(const FString& Category, const FString& Key, int32 Value);
	static void PostIntValue(const FString& Category, const FString& Key, int32 Value1, int32 Value2);
	static void PostIntValue(const FString& Category, const FString& Key, int32 Value1, int32 Value2, int32 Value3);
	static void PostStringValue(const FString& Category, const FString& Key, const FString& Value);
	static void SetLabel(const FString& LabelName);
	static void AddNote(const FString& NoteText);
	static void DeepMark(const FString& Name);
	static void DeepCounter(const FString& Name, float Value);
	static void DeepPush(const FString& Name);
	static void DeepPop(const FString& Name);

private:
	static FPerfDogExtension* ExtensionInstance;
};
