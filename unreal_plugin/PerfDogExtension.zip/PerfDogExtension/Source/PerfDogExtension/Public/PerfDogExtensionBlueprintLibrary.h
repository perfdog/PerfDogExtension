// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "PerfDogExtensionBlueprintLibrary.generated.h"

/**
 * PerfDog扩展蓝图函数库
 * 提供PerfDog性能监控的蓝图接口
 */
UCLASS()
class PERFDOGEXTENSION_API UPerfDogExtensionBlueprintLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/**
	 * 启用PerfDog扩展
	 * @return 初始化结果，0表示成功
	 */
	UFUNCTION(BlueprintCallable, Category = "PerfDog")
	static int32 EnablePerfDogExtension();

	/**
	 * 检查是否开始测试
	 * @return 是否已开始测试
	 */
	UFUNCTION(BlueprintCallable, Category = "PerfDog")
	static bool IsTestStarted();

	/**
	 * 上报浮点数据
	 * @param Category 数据分类
	 * @param Key 数据键名
	 * @param Value 数据值
	 */
	UFUNCTION(BlueprintCallable, Category = "PerfDog")
	static void PostFloatValue(const FString& Category, const FString& Key, float Value);

	/**
	 * 上报两个浮点数据
	 * @param Category 数据分类
	 * @param Key 数据键名
	 * @param Value1 第一个数据值
	 * @param Value2 第二个数据值
	 */
	UFUNCTION(BlueprintCallable, Category = "PerfDog")
	static void PostFloatValue2(const FString& Category, const FString& Key, float Value1, float Value2);

	/**
	 * 上报三个浮点数据
	 * @param Category 数据分类
	 * @param Key 数据键名
	 * @param Value1 第一个数据值
	 * @param Value2 第二个数据值
	 * @param Value3 第三个数据值
	 */
	UFUNCTION(BlueprintCallable, Category = "PerfDog")
	static void PostFloatValue3(const FString& Category, const FString& Key, float Value1, float Value2, float Value3);

	/**
	 * 上报整数数据
	 * @param Category 数据分类
	 * @param Key 数据键名
	 * @param Value 数据值
	 */
	UFUNCTION(BlueprintCallable, Category = "PerfDog")
	static void PostIntValue(const FString& Category, const FString& Key, int32 Value);

	/**
	 * 上报两个整数数据
	 * @param Category 数据分类
	 * @param Key 数据键名
	 * @param Value1 第一个数据值
	 * @param Value2 第二个数据值
	 */
	UFUNCTION(BlueprintCallable, Category = "PerfDog")
	static void PostIntValue2(const FString& Category, const FString& Key, int32 Value1, int32 Value2);

	/**
	 * 上报三个整数数据
	 * @param Category 数据分类
	 * @param Key 数据键名
	 * @param Value1 第一个数据值
	 * @param Value2 第二个数据值
	 * @param Value3 第三个数据值
	 */
	UFUNCTION(BlueprintCallable, Category = "PerfDog")
	static void PostIntValue3(const FString& Category, const FString& Key, int32 Value1, int32 Value2, int32 Value3);

	/**
	 * 上报字符串数据
	 * @param Category 数据分类
	 * @param Key 数据键名
	 * @param Value 数据值
	 */
	UFUNCTION(BlueprintCallable, Category = "PerfDog")
	static void PostStringValue(const FString& Category, const FString& Key, const FString& Value);

	/**
	 * 设置标签
	 * @param LabelName 标签名称
	 */
	UFUNCTION(BlueprintCallable, Category = "PerfDog")
	static void SetLabel(const FString& LabelName);

	/**
	 * 添加注释
	 * @param NoteText 注释文本
	 */
	UFUNCTION(BlueprintCallable, Category = "PerfDog")
	static void AddNote(const FString& NoteText);
}; 