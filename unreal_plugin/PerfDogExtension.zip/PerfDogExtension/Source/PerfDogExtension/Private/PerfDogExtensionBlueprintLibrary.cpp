// Copyright Epic Games, Inc. All Rights Reserved.

#include "PerfDogExtensionBlueprintLibrary.h"
#include "PerfDogExtension.h"

int32 UPerfDogExtensionBlueprintLibrary::EnablePerfDogExtension()
{
	return FPerfDogExtensionModule::EnablePerfDogExtension();
}

bool UPerfDogExtensionBlueprintLibrary::IsTestStarted()
{
	return FPerfDogExtensionModule::IsTestStarted();
}

void UPerfDogExtensionBlueprintLibrary::PostFloatValue(const FString& Category, const FString& Key, float Value)
{
	FPerfDogExtensionModule::PostFloatValue(Category, Key, Value);
}

void UPerfDogExtensionBlueprintLibrary::PostFloatValue2(const FString& Category, const FString& Key, float Value1, float Value2)
{
	FPerfDogExtensionModule::PostFloatValue(Category, Key, Value1, Value2);
}

void UPerfDogExtensionBlueprintLibrary::PostFloatValue3(const FString& Category, const FString& Key, float Value1, float Value2, float Value3)
{
	FPerfDogExtensionModule::PostFloatValue(Category, Key, Value1, Value2, Value3);
}

void UPerfDogExtensionBlueprintLibrary::PostIntValue(const FString& Category, const FString& Key, int32 Value)
{
	FPerfDogExtensionModule::PostIntValue(Category, Key, Value);
}

void UPerfDogExtensionBlueprintLibrary::PostIntValue2(const FString& Category, const FString& Key, int32 Value1, int32 Value2)
{
	FPerfDogExtensionModule::PostIntValue(Category, Key, Value1, Value2);
}

void UPerfDogExtensionBlueprintLibrary::PostIntValue3(const FString& Category, const FString& Key, int32 Value1, int32 Value2, int32 Value3)
{
	FPerfDogExtensionModule::PostIntValue(Category, Key, Value1, Value2, Value3);
}

void UPerfDogExtensionBlueprintLibrary::PostStringValue(const FString& Category, const FString& Key, const FString& Value)
{
	FPerfDogExtensionModule::PostStringValue(Category, Key, Value);
}

void UPerfDogExtensionBlueprintLibrary::SetLabel(const FString& LabelName)
{
	FPerfDogExtensionModule::SetLabel(LabelName);
}

void UPerfDogExtensionBlueprintLibrary::AddNote(const FString& NoteText)
{
	FPerfDogExtensionModule::AddNote(NoteText);
} 