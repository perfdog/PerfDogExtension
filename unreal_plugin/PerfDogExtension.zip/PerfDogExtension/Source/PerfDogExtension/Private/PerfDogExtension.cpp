// Copyright Epic Games, Inc. All Rights Reserved.

#include "PerfDogExtension.h"
#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "Sockets.h"
#include "SocketSubsystem.h"
#include "IPAddress.h"
#include "HAL/PlatformFilemanager.h"
#include "HAL/RunnableThread.h"
#include "GenericPlatform/GenericPlatformProcess.h"
#include "Misc/Timespan.h"

#if PLATFORM_WINDOWS
#include "Windows/AllowWindowsPlatformTypes.h"
#include <winsock2.h>
#include <windows.h>
#include "Windows/HideWindowsPlatformTypes.h"
#elif PLATFORM_MAC || PLATFORM_IOS
#include <mach/mach_time.h>
#elif PLATFORM_ANDROID
#include <pthread.h>
#include <time.h>
#endif

DEFINE_LOG_CATEGORY_STATIC(LogPerfDogExtension, Log, All);

static constexpr int32 SOCKET_PORT = 53000;
static constexpr int32 BLOCK_SIZE = 4096;

//================================================================
// Buffer实现
//================================================================

FPerfDogBuffer::FPerfDogBuffer(uint8* InBuffer, int32 InCapacity)
	: Buffer(InBuffer), Capacity(InCapacity), Position(0), bIsOverflow(false)
{
}

void FPerfDogBuffer::WriteInt32(int32 Value)
{
	WriteBytes(&Value, sizeof(Value));
}

int32 FPerfDogBuffer::ReadInt32()
{
	int32 Value;
	ReadBytes(&Value, sizeof(Value));
	return Value;
}

void FPerfDogBuffer::WriteUint32(uint32 Value)
{
	WriteBytes(&Value, sizeof(Value));
}

uint32 FPerfDogBuffer::ReadUint32()
{
	uint32 Value;
	ReadBytes(&Value, sizeof(Value));
	return Value;
}

void FPerfDogBuffer::WriteUint64(uint64 Value)
{
	WriteBytes(&Value, sizeof(Value));
}

uint64 FPerfDogBuffer::ReadUint64()
{
	uint64 Value;
	ReadBytes(&Value, sizeof(Value));
	return Value;
}

void FPerfDogBuffer::WriteFloat(float Value)
{
	WriteBytes(&Value, sizeof(Value));
}

float FPerfDogBuffer::ReadFloat()
{
	float Value;
	ReadBytes(&Value, sizeof(Value));
	return Value;
}

void FPerfDogBuffer::WriteString(const FString& Value)
{
	FTCHARToUTF8 UTF8String(*Value);
	int32 Length = UTF8String.Length();
	WriteUint32(Length);
	if (Length > 0)
	{
		WriteBytes(UTF8String.Get(), Length);
	}
}

void FPerfDogBuffer::ReadString(FString& Value)
{
	uint32 Length = ReadUint32();
	Value.Empty();
	if (Length > 0)
	{
		FUTF8ToTCHAR TCHARString((const ANSICHAR*)(Buffer + Position), Length);
		Value = FString(TCHARString.Length(), TCHARString.Get());
		Position += Length;
	}
}

void FPerfDogBuffer::WriteBytes(const void* Data, uint32 Size)
{
	if (GetRemaining() >= (int32)Size)
	{
		FMemory::Memcpy(Buffer + Position, Data, Size);
		Position += Size;
	}
	else
	{
		bIsOverflow = true;
	}
}

void FPerfDogBuffer::ReadBytes(void* Data, uint32 Size)
{
	if (GetRemaining() >= (int32)Size)
	{
		FMemory::Memcpy(Data, Buffer + Position, Size);
		Position += Size;
	}
	else
	{
		bIsOverflow = true;
	}
}

//================================================================
// StringOrId实现
//================================================================

FStringOrId::FStringOrId() : Id(InvalidStringId) {}

FStringOrId::FStringOrId(uint32 InId) : Id(InId) {}

FStringOrId::FStringOrId(const FString& InString) : Id(InvalidStringId), String(InString) {}

FStringOrId::FStringOrId(const FStringOrId& Other) : Id(Other.Id), String(Other.String) {}

FStringOrId::FStringOrId(FStringOrId&& Other) : Id(Other.Id), String(MoveTemp(Other.String))
{
	Other.Id = InvalidStringId;
}

FStringOrId& FStringOrId::operator=(const FStringOrId& Other)
{
	if (this != &Other)
	{
		Id = Other.Id;
		String = Other.String;
	}
	return *this;
}

FStringOrId& FStringOrId::operator=(FStringOrId&& Other)
{
	if (this != &Other)
	{
		Id = Other.Id;
		String = MoveTemp(Other.String);
		Other.Id = InvalidStringId;
	}
	return *this;
}

void FStringOrId::Serialize(FPerfDogBuffer& Buffer) const
{
	Buffer.WriteUint32(Id);
	Buffer.WriteString(String);
}

void FStringOrId::Deserialize(FPerfDogBuffer& Buffer)
{
	Id = Buffer.ReadUint32();
	Buffer.ReadString(String);
}

//================================================================
// 消息类实现
//================================================================

// StringMapMessage
FStringMapMessage::FStringMapMessage(uint32 InId, const FString& InName)
	: Id(InId), Name(InName)
{
}

void FStringMapMessage::Serialize(FPerfDogBuffer& Buffer) const
{
	Buffer.WriteUint32(Id);
	Buffer.WriteString(Name);
}

void FStringMapMessage::Deserialize(FPerfDogBuffer& Buffer)
{
	Id = Buffer.ReadUint32();
	Buffer.ReadString(Name);
}

// CustomValueMessage
FCustomValueMessage::FCustomValueMessage(uint64 InTime, const FStringOrId& InCategory, const FStringOrId& InKeyName)
	: Time(InTime), Category(InCategory), KeyName(InKeyName)
{
}

void FCustomValueMessage::Serialize(FPerfDogBuffer& Buffer) const
{
	Buffer.WriteUint64(Time);
	Category.Serialize(Buffer);
	KeyName.Serialize(Buffer);
}

void FCustomValueMessage::Deserialize(FPerfDogBuffer& Buffer)
{
	Time = Buffer.ReadUint64();
	Category.Deserialize(Buffer);
	KeyName.Deserialize(Buffer);
}

// CustomFloatValueMessage
FCustomFloatValueMessage::FCustomFloatValueMessage(uint64 Time, const FStringOrId& Category, const FStringOrId& KeyName, const TArray<float>& InValues)
	: FCustomValueMessage(Time, Category, KeyName), Values(InValues)
{
}

void FCustomFloatValueMessage::Serialize(FPerfDogBuffer& Buffer) const
{
	FCustomValueMessage::Serialize(Buffer);
	Buffer.WriteUint32(Values.Num());
	for (float Value : Values)
	{
		Buffer.WriteFloat(Value);
	}
}

void FCustomFloatValueMessage::Deserialize(FPerfDogBuffer& Buffer)
{
	FCustomValueMessage::Deserialize(Buffer);
	uint32 Count = Buffer.ReadUint32();
	if (Count > 0)
	{
		Values.Reserve(Count);
		for (uint32 i = 0; i < Count; i++)
		{
			Values.Add(Buffer.ReadFloat());
		}
	}
}

// CustomIntegerValueMessage
FCustomIntegerValueMessage::FCustomIntegerValueMessage(uint64 Time, const FStringOrId& Category, const FStringOrId& KeyName, const TArray<int32>& InValues)
	: FCustomValueMessage(Time, Category, KeyName), Values(InValues)
{
}

void FCustomIntegerValueMessage::Serialize(FPerfDogBuffer& Buffer) const
{
	FCustomValueMessage::Serialize(Buffer);
	Buffer.WriteUint32(Values.Num());
	for (int32 Value : Values)
	{
		Buffer.WriteInt32(Value);
	}
}

void FCustomIntegerValueMessage::Deserialize(FPerfDogBuffer& Buffer)
{
	FCustomValueMessage::Deserialize(Buffer);
	uint32 Count = Buffer.ReadUint32();
	if (Count > 0)
	{
		Values.Reserve(Count);
		for (uint32 i = 0; i < Count; i++)
		{
			Values.Add(Buffer.ReadInt32());
		}
	}
}

// CustomStringValueMessage
FCustomStringValueMessage::FCustomStringValueMessage(uint64 Time, const FStringOrId& Category, const FStringOrId& KeyName, const FStringOrId& InValue)
	: FCustomValueMessage(Time, Category, KeyName), Value(InValue)
{
}

void FCustomStringValueMessage::Serialize(FPerfDogBuffer& Buffer) const
{
	FCustomValueMessage::Serialize(Buffer);
	Value.Serialize(Buffer);
}

void FCustomStringValueMessage::Deserialize(FPerfDogBuffer& Buffer)
{
	FCustomValueMessage::Deserialize(Buffer);
	Value.Deserialize(Buffer);
}

// SetLabelReqMessage
FSetLabelReqMessage::FSetLabelReqMessage(uint64 InTime, const FString& InName)
	: Time(InTime), Name(InName)
{
}

void FSetLabelReqMessage::Serialize(FPerfDogBuffer& Buffer) const
{
	Buffer.WriteUint64(Time);
	Buffer.WriteString(Name);
}

void FSetLabelReqMessage::Deserialize(FPerfDogBuffer& Buffer)
{
	Time = Buffer.ReadUint64();
	Buffer.ReadString(Name);
}

// AddNoteReqMessage
FAddNoteReqMessage::FAddNoteReqMessage(uint64 InTime, const FString& InName)
	: Time(InTime), Name(InName)
{
}

void FAddNoteReqMessage::Serialize(FPerfDogBuffer& Buffer) const
{
	Buffer.WriteUint64(Time);
	Buffer.WriteString(Name);
}

void FAddNoteReqMessage::Deserialize(FPerfDogBuffer& Buffer)
{
	Time = Buffer.ReadUint64();
	Buffer.ReadString(Name);
}

// DeepMessage
FDeepMessage::FDeepMessage(uint64 InTime, int32 InThreadId, const FStringOrId& InName)
	: Time(InTime), ThreadId(InThreadId), Name(InName)
{
}

void FDeepMessage::Serialize(FPerfDogBuffer& Buffer) const
{
	Buffer.WriteUint64(Time);
	Buffer.WriteInt32(ThreadId);
	Name.Serialize(Buffer);
}

void FDeepMessage::Deserialize(FPerfDogBuffer& Buffer)
{
	Time = Buffer.ReadUint64();
	ThreadId = Buffer.ReadInt32();
	Name.Deserialize(Buffer);
}

// DeepMarkReqMessage
FDeepMarkReqMessage::FDeepMarkReqMessage(uint64 Time, int32 ThreadId, const FStringOrId& Name)
	: FDeepMessage(Time, ThreadId, Name)
{
}

// DeepCounterReqMessage
FDeepCounterReqMessage::FDeepCounterReqMessage(uint64 InTime, const FStringOrId& InName, float InValue)
	: Time(InTime), Name(InName), Value(InValue)
{
}

void FDeepCounterReqMessage::Serialize(FPerfDogBuffer& Buffer) const
{
	Buffer.WriteUint64(Time);
	Name.Serialize(Buffer);
	Buffer.WriteFloat(Value);
}

void FDeepCounterReqMessage::Deserialize(FPerfDogBuffer& Buffer)
{
	Time = Buffer.ReadUint64();
	Name.Deserialize(Buffer);
	Value = Buffer.ReadFloat();
}

// DeepPushReqMessage
FDeepPushReqMessage::FDeepPushReqMessage(uint64 Time, int32 ThreadId, const FStringOrId& Name)
	: FDeepMessage(Time, ThreadId, Name)
{
}

// DeepPopReqMessage
FDeepPopReqMessage::FDeepPopReqMessage(uint64 Time, int32 ThreadId, const FStringOrId& Name)
	: FDeepMessage(Time, ThreadId, Name)
{
}

// EmptyMessageWrapper
FEmptyMessageWrapper::FEmptyMessageWrapper(EMessageType Type)
	: MessageType(Type)
{
}

//================================================================
// Block实现
//================================================================

FPerfDogBlock::FPerfDogBlock(int32 InCapacity)
	: Capacity(InCapacity), Cursor(0)
{
	Data.SetNumUninitialized(Capacity);
}

//================================================================
// PerfDogExtension实现（整合平台相关、Socket、线程、FRunnable接口）
//================================================================

FPerfDogExtension::FPerfDogExtension()
	: bInitialized(false)
	, InitializeResult(0)
	, bStartTest(false)
	, bShouldStop(false)
	, bStopDrainBuffer(false)
	, NextStringId(0)
	, DataProcessingThreadPtr(nullptr)
	, DataProcessingRunnable(nullptr)
	, ServerSocket(nullptr)
	, ClientSocket(nullptr)
	, NetworkThreadPtr(nullptr)
{
#if PLATFORM_MAC || PLATFORM_IOS
	mach_timebase_info_data_t TimebaseInfo;
	mach_timebase_info(&TimebaseInfo);
	TimeFrequency = (1000000000ULL * TimebaseInfo.denom) / TimebaseInfo.numer;
#endif
}

FPerfDogExtension::~FPerfDogExtension()
{
	StopServer();
	StopTest();
}

int32 FPerfDogExtension::Initialize()
{
	FScopeLock Lock(&StateLock);
	if (!bInitialized)
	{
		bInitialized = true;
		InitializeResult = StartServer();
		ErrorLog(TEXT("init return %d"), InitializeResult);
	}
	return InitializeResult;
}

// FRunnable接口实现
bool FPerfDogExtension::Init()
{
	return true;
}

uint32 FPerfDogExtension::Run()
{
	NetworkThread();
	return 0;
}

void FPerfDogExtension::Stop()
{
	bShouldStop = true;
}

void FPerfDogExtension::Exit()
{
}

int32 FPerfDogExtension::StartServer()
{
	FScopeLock Lock(&StateLock);
	if (NetworkThreadPtr)
	{
		return 0;
	}
	ISocketSubsystem* SocketSubsystem = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM);
	ServerSocket = SocketSubsystem->CreateSocket(NAME_Stream, TEXT("PerfDogServer"), false);
	if (!ServerSocket)
	{
		return 1;
	}
	ServerSocket->SetReuseAddr(true);
	ServerSocket->SetNonBlocking(false); // 阻塞模式
	TSharedRef<FInternetAddr> ListenAddr = SocketSubsystem->CreateInternetAddr();
	ListenAddr->SetAnyAddress();
	ListenAddr->SetPort(SOCKET_PORT);
	if (!ServerSocket->Bind(*ListenAddr))
	{
		SocketSubsystem->DestroySocket(ServerSocket);
		ServerSocket = nullptr;
		return 1;
	}
	if (!ServerSocket->Listen(1))
	{
		SocketSubsystem->DestroySocket(ServerSocket);
		ServerSocket = nullptr;
		return 1;
	}
	bShouldStop = false;
	NetworkThreadPtr = FRunnableThread::Create(this, TEXT("PerfDogNetworkThread"));
	if (!NetworkThreadPtr)
	{
		SocketSubsystem->DestroySocket(ServerSocket);
		ServerSocket = nullptr;
		return 1;
	}
	return 0;
}

void FPerfDogExtension::StopServer()
{
	FScopeLock Lock(&StateLock);

	// 设置停止标志
	bShouldStop = true;

	// 等待网络线程完成
	if (NetworkThreadPtr)
	{
		NetworkThreadPtr->WaitForCompletion();
		delete NetworkThreadPtr;
		NetworkThreadPtr = nullptr;
	}

	// 关闭Socket连接
	if (ClientSocket)
	{
		ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(ClientSocket);
		ClientSocket = nullptr;
	}

	if (ServerSocket)
	{
		ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(ServerSocket);
		ServerSocket = nullptr;
	}
}

int32 FPerfDogExtension::SendData(const void* Buffer, int32 Size)
{
	FScopeLock Lock(&StateLock);
	if (ClientSocket)
	{
		int32 BytesSent = 0;
		if (ClientSocket->Send(static_cast<const uint8*>(Buffer), Size, BytesSent))
		{
			if (BytesSent != Size)
			{
				ErrorLog(TEXT("send error:size %d,ret %d"), Size, BytesSent);
			}
			return BytesSent;
		}
		else
		{
			return 0;
		}
	}
	return 0;
}

void FPerfDogExtension::ErrorLog(const TCHAR* Format, ...)
{
	TCHAR Buffer[1024];
	va_list Args;
	va_start(Args, Format);
	FCString::GetVarArgs(Buffer, UE_ARRAY_COUNT(Buffer), Format, Args);
	va_end(Args);
	UE_LOG(LogPerfDogExtension, Log, TEXT("%s"), Buffer);
}

uint64 FPerfDogExtension::CurrentTime() // 毫秒 ms
{
#if PLATFORM_WINDOWS
	LARGE_INTEGER Counter, Frequency;
	QueryPerformanceCounter(&Counter);
	QueryPerformanceFrequency(&Frequency);
	return (Counter.QuadPart * 1000) / Frequency.QuadPart;
#elif PLATFORM_MAC || PLATFORM_IOS
	uint64 Time = mach_absolute_time();
	return (Time * 1000) / TimeFrequency;
#elif PLATFORM_ANDROID
	timespec t;
	if (clock_gettime(CLOCK_MONOTONIC, &t))
	{
		ErrorLog(TEXT("clock_gettime error"));
		return 0;
}
	return t.tv_sec * (uint64)1e3 + t.tv_nsec / 1000000;
#else
	return FPlatformTime::Cycles64() / 1000000; // 简化实现
#endif
}

int32 FPerfDogExtension::CurrentThreadId()
{
	return FPlatformTLS::GetCurrentThreadId();
}

int32 FPerfDogExtension::ReadWithTimeout(int32 TimeoutMs, uint8* Buffer, int32 Count)
{
	if (!ClientSocket)
	{
		return -1;
	}

	// 使用Wait方法检查数据是否可读，带超时
	FTimespan Timeout = FTimespan::FromMilliseconds(TimeoutMs);
	if (ClientSocket->Wait(ESocketWaitConditions::WaitForRead, Timeout))
	{
		// 有数据可读，接收数据
		int32 BytesRead = 0;
		bool bRecvOk = ClientSocket->Recv(Buffer, Count, BytesRead);

		if (bRecvOk && BytesRead > 0)
		{
			return BytesRead;
		}
		else
		{
			// 接收失败或收到0字节（连接关闭）
			return -1;
		}
	}
	else
	{
		// 超时
		return 0;
	}
}

void FPerfDogExtension::NetworkThread()
{
	while (!bShouldStop)
	{
		if (!ClientSocket)
		{
			// 检查ServerSocket是否还有效
			if (!ServerSocket)
			{
				break; // ServerSocket已被关闭，退出线程
			}

			// 使用带超时的Wait检查是否有连接请求，而不是直接阻塞Accept
			FTimespan Timeout = FTimespan::FromMilliseconds(100);
			if (ServerSocket->Wait(ESocketWaitConditions::WaitForRead, Timeout))
			{
				// 有连接请求时才调用Accept
				TSharedRef<FInternetAddr> ClientAddr = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->CreateInternetAddr();
				ClientSocket = ServerSocket->Accept(*ClientAddr, TEXT("PerfDogClient"));
				if (ClientSocket)
				{
					ClientSocket->SetNonBlocking(false); // 阻塞模式
					ErrorLog(TEXT("client connected"));
					OnConnect();
				}
			}
			// 100ms超时后会继续循环检查bShouldStop标志
		}
		else
		{
			ProcessClientData();
		}
	}
}

void FPerfDogExtension::ProcessClientData()
{
	static TArray<uint8> DataBuffer;
	uint8 RecvBuf[4096];
	int32 BytesRead = ReadWithTimeout(100, RecvBuf, sizeof(RecvBuf));
	if (BytesRead == -1)
	{
		ErrorLog(TEXT("client disconnect"));
		OnDisconnect();
		ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(ClientSocket);
		ClientSocket = nullptr;
		DataBuffer.Empty();
		return;
	}
	if (BytesRead == 0)
	{
		// 超时，继续下一次循环
		return;
	}
	int32 OldSize = DataBuffer.Num();
	DataBuffer.SetNumUninitialized(OldSize + BytesRead);
	FMemory::Memcpy(DataBuffer.GetData() + OldSize, RecvBuf, BytesRead);
	// parse data
	// 解析数据
	int32 BufferPos = 0;
	while (DataBuffer.Num() - BufferPos >= MESSAGE_HEADER_LENGTH)
	{
		FMessageHeader Header;
		FMemory::Memcpy(&Header, DataBuffer.GetData() + BufferPos, MESSAGE_HEADER_LENGTH);
		if (DataBuffer.Num() - BufferPos < MESSAGE_HEADER_LENGTH + Header.Length)
		{
			break; // 数据还没收全
		}
		if (Header.Length > MAX_MESSAGE_LENGTH)
		{
			ErrorLog(TEXT("message too large:%u %u"), Header.Type, Header.Length);
			BufferPos += MESSAGE_HEADER_LENGTH + Header.Length;
			continue;
		}
		if (Header.Length == 0)
		{
			OnMessage(Header.Type, nullptr);
		}
		else
		{
			const uint8* MessageData = DataBuffer.GetData() + BufferPos + MESSAGE_HEADER_LENGTH;
			FPerfDogBuffer Buffer(const_cast<uint8*>(MessageData), Header.Length);
			FPerfDogMessage* MsgObj = nullptr;

			if (Header.Type == static_cast<uint16>(EMessageType::StringMap))
			{
				auto* Msg = new FStringMapMessage();
				Msg->Deserialize(Buffer);
				if (Buffer.IsOverflow())
				{
					ErrorLog(TEXT("message %u overflow"), Header.Type);
					delete Msg;
					OnDisconnect();
					ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(ClientSocket);
					ClientSocket = nullptr;
					DataBuffer.Empty();
					return;
				}
				MsgObj = Msg;
			}
			else if (Header.Type == static_cast<uint16>(EMessageType::CustomIntegerValue))
			{
				auto* Msg = new FCustomIntegerValueMessage();
				Msg->Deserialize(Buffer);
				if (Buffer.IsOverflow())
				{
					ErrorLog(TEXT("message %u overflow"), Header.Type);
					delete Msg;
					OnDisconnect();
					ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(ClientSocket);
					ClientSocket = nullptr;
					DataBuffer.Empty();
					return;
				}
				MsgObj = Msg;
			}
			else
			{
				ErrorLog(TEXT("unknown %d"), Header.Type);
			}

			if (MsgObj)
			{
				OnMessage(Header.Type, MsgObj);
				delete MsgObj;
			}
		}
		BufferPos += MESSAGE_HEADER_LENGTH + Header.Length;
	}
	// Clear read data
	// 清除已读的数据
	if (BufferPos > 0)
	{
		DataBuffer.RemoveAt(0, BufferPos, false);
	}
}

void FPerfDogExtension::OnConnect()
{
	SendStreamHeader();
}

void FPerfDogExtension::OnMessage(uint16 Type, const FPerfDogMessage* Message)
{
	switch (static_cast<EMessageType>(Type))
	{
	case EMessageType::StartTestReq:
		StartTest();
		break;
	case EMessageType::StopTestReq:
		StopTest();
		break;
	default:
		ErrorLog(TEXT("unknown message:%u"), Type);
		break;
	}
}

void FPerfDogExtension::OnDisconnect()
{
	StopTest();
}

void FPerfDogExtension::StartTest()
{
	FScopeLock Lock(&StateLock);

	if (!DataProcessingThreadPtr)
	{
		bStopDrainBuffer = false;
		bStartTest = true;
		ClearData();
		StartDataProcessingThread();
	}

	FEmptyMessageWrapper Response(EMessageType::StartTestRsp);
	WriteMessage(Response);
	ErrorLog(TEXT("start test"));
}

void FPerfDogExtension::StopTest()
{
	FScopeLock Lock(&StateLock);

	if (DataProcessingThreadPtr)
	{
		bStopDrainBuffer = true;
		bStartTest = false;
		StopDataProcessingThread();
		ClearData();
		ErrorLog(TEXT("stop test"));
	}

	FEmptyMessageWrapper Response(EMessageType::StopTestRsp);
	WriteMessage(Response);
}

void FPerfDogExtension::ClearData()
{
	FScopeLock BufferLockGuard(&this->BufferLock);
	FScopeLock StringLockGuard(&this->StringMapLock);

	BlockList.Empty();
	StringToIdMap.Empty();
	NextStringId = 0;
}

int32 FPerfDogExtension::WriteData(const void* Buffer, int32 Size)
{
	FScopeLock Lock(&BufferLock);

	// 前插链表逻辑：如果列表为空或第一个block空间不足，在头部插入新block
	if (BlockList.Num() == 0 || BlockList[0]->Available() < Size)
	{
		BlockList.Insert(MakeShareable(new FPerfDogBlock(BLOCK_SIZE)), 0);
	}

	FPerfDogBlockPtr& Block = BlockList[0];
	FMemory::Memcpy(&Block->Data[Block->Cursor], Buffer, Size);
	Block->Cursor += Size;

	return 0;
}

void FPerfDogExtension::WriteMessage(const FPerfDogMessage& Message)
{
	uint8 TempBuffer[MESSAGE_HEADER_LENGTH + MAX_MESSAGE_LENGTH];

	FPerfDogBuffer Buffer(TempBuffer + MESSAGE_HEADER_LENGTH, sizeof(TempBuffer) - MESSAGE_HEADER_LENGTH);
	Message.Serialize(Buffer);

	FMessageHeader* MessageHeader = reinterpret_cast<FMessageHeader*>(TempBuffer);
	MessageHeader->Length = static_cast<uint16>(Buffer.GetDataSize());
	MessageHeader->Type = static_cast<uint16>(Message.GetType());

	WriteData(TempBuffer, MESSAGE_HEADER_LENGTH + Buffer.GetDataSize());
}

FStringOrId FPerfDogExtension::StringToId(const FString& String)
{
	FScopeLock Lock(&StringMapLock);

	if (uint32* ExistingId = StringToIdMap.Find(String))
	{
		return FStringOrId(*ExistingId);
	}
	else
	{
		uint32 NewId = ++NextStringId;
		StringToIdMap.Add(String, NewId);

		FStringMapMessage StringMapMsg(NewId, String);
		WriteMessage(StringMapMsg);
		return FStringOrId(NewId);
	}
}

void FPerfDogExtension::SendStreamHeader()
{
	FProtocolHeader Header;
	SendData(&Header, sizeof(Header));
}

void FPerfDogExtension::StartDataProcessingThread()
{
	if (!DataProcessingThreadPtr)
	{
		DataProcessingRunnable = new FPerfDogDataProcessingRunnable(this);
		DataProcessingThreadPtr = FRunnableThread::Create(DataProcessingRunnable, TEXT("PerfDogDataProcessingThread"));
	}
}

void FPerfDogExtension::StopDataProcessingThread()
{
	if (DataProcessingThreadPtr)
	{
		DataProcessingThreadPtr->WaitForCompletion();
		delete DataProcessingThreadPtr;
		delete DataProcessingRunnable;
		DataProcessingThreadPtr = nullptr;
		DataProcessingRunnable = nullptr;
	}
}

void FPerfDogExtension::DrainBuffer()
{
	while (!bStopDrainBuffer)
	{
		TArray<FPerfDogBlockPtr> CommitList;

		{
			FScopeLock Lock(&BufferLock);
			CommitList = MoveTemp(BlockList);
			BlockList.Empty();
		}

		for (int32 i = CommitList.Num() - 1; i >= 0; --i)
		{
			const FPerfDogBlockPtr& Block = CommitList[i];
			if (Block->Cursor > 0)
			{
				SendData(Block->Data.GetData(), Block->Cursor);
			}
		}

		FPlatformProcess::Sleep(0.1f); // 100ms
	}
}

//================================================================
// 公共接口实现
//================================================================

void FPerfDogExtension::PostValueF(const FString& Category, const FString& Key, float Value)
{
	if (IsStartTest())
	{
		FCustomFloatValueMessage Message(CurrentTime(), StringToId(Category), StringToId(Key), { Value });
		WriteMessage(Message);
	}
}

void FPerfDogExtension::PostValueF(const FString& Category, const FString& Key, float Value1, float Value2)
{
	if (IsStartTest())
	{
		FCustomFloatValueMessage Message(CurrentTime(), StringToId(Category), StringToId(Key), { Value1, Value2 });
		WriteMessage(Message);
	}
}

void FPerfDogExtension::PostValueF(const FString& Category, const FString& Key, float Value1, float Value2, float Value3)
{
	if (IsStartTest())
	{
		FCustomFloatValueMessage Message(CurrentTime(), StringToId(Category), StringToId(Key), { Value1, Value2, Value3 });
		WriteMessage(Message);
	}
}

void FPerfDogExtension::PostValueI(const FString& Category, const FString& Key, int32 Value)
{
	if (IsStartTest())
	{
		FCustomIntegerValueMessage Message(CurrentTime(), StringToId(Category), StringToId(Key), { Value });
		WriteMessage(Message);
	}
}

void FPerfDogExtension::PostValueI(const FString& Category, const FString& Key, int32 Value1, int32 Value2)
{
	if (IsStartTest())
	{
		FCustomIntegerValueMessage Message(CurrentTime(), StringToId(Category), StringToId(Key), { Value1, Value2 });
		WriteMessage(Message);
	}
}

void FPerfDogExtension::PostValueI(const FString& Category, const FString& Key, int32 Value1, int32 Value2, int32 Value3)
{
	if (IsStartTest())
	{
		FCustomIntegerValueMessage Message(CurrentTime(), StringToId(Category), StringToId(Key), { Value1, Value2, Value3 });
		WriteMessage(Message);
	}
}

void FPerfDogExtension::PostValueS(const FString& Category, const FString& Key, const FString& Value)
{
	if (IsStartTest())
	{
		FCustomStringValueMessage Message(CurrentTime(), StringToId(Category), StringToId(Key), StringToId(Value));
		WriteMessage(Message);
	}
}

void FPerfDogExtension::SetLabel(const FString& Name)
{
	if (IsStartTest())
	{
		FSetLabelReqMessage Message(CurrentTime(), Name);
		WriteMessage(Message);
	}
}

void FPerfDogExtension::AddNote(const FString& Name)
{
	if (IsStartTest())
	{
		FAddNoteReqMessage Message(CurrentTime(), Name);
		WriteMessage(Message);
	}
}

void FPerfDogExtension::DeepMark(const FString& Name)
{
	if (IsStartTest())
	{
		FDeepMarkReqMessage Message(CurrentTime(), CurrentThreadId(), StringToId(Name));
		WriteMessage(Message);
	}
}

void FPerfDogExtension::DeepCounter(const FString& Name, float Value)
{
	if (IsStartTest())
	{
		FDeepCounterReqMessage Message(CurrentTime(), StringToId(Name), Value);
		WriteMessage(Message);
	}
}

void FPerfDogExtension::DeepPush(const FString& Name)
{
	if (IsStartTest())
	{
		FDeepPushReqMessage Message(CurrentTime(), CurrentThreadId(), StringToId(Name));
		WriteMessage(Message);
	}
}

void FPerfDogExtension::DeepPop(const FString& Name)
{
	if (IsStartTest())
	{
		FDeepPopReqMessage Message(CurrentTime(), CurrentThreadId(), StringToId(Name));
		WriteMessage(Message);
	}
}

//================================================================
// 数据处理线程实现
//================================================================

uint32 FPerfDogDataProcessingRunnable::Run()
{
	if (Extension)
	{
		Extension->DrainBuffer();
	}
	return 0;
}

//================================================================
// 模块实现
//================================================================

// PerfDogExtensionModule实现，ExtensionInstance类型为FPerfDogExtension*
FPerfDogExtension* FPerfDogExtensionModule::ExtensionInstance = nullptr;

void FPerfDogExtensionModule::StartupModule()
{
	ExtensionInstance = new FPerfDogExtension();
}

void FPerfDogExtensionModule::ShutdownModule()
{
	if (ExtensionInstance)
	{
		delete ExtensionInstance;
		ExtensionInstance = nullptr;
	}
}

FPerfDogExtensionModule& FPerfDogExtensionModule::Get()
{
	return FModuleManager::LoadModuleChecked<FPerfDogExtensionModule>("PerfDogExtension");
}

int32 FPerfDogExtensionModule::EnablePerfDogExtension()
{
	return ExtensionInstance ? ExtensionInstance->Initialize() : -1;
}

bool FPerfDogExtensionModule::IsTestStarted()
{
	return ExtensionInstance ? ExtensionInstance->IsStartTest() : false;
}

void FPerfDogExtensionModule::PostFloatValue(const FString& Category, const FString& Key, float Value)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->PostValueF(Category, Key, Value);
	}
}

void FPerfDogExtensionModule::PostFloatValue(const FString& Category, const FString& Key, float Value1, float Value2)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->PostValueF(Category, Key, Value1, Value2);
	}
}

void FPerfDogExtensionModule::PostFloatValue(const FString& Category, const FString& Key, float Value1, float Value2, float Value3)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->PostValueF(Category, Key, Value1, Value2, Value3);
	}
}

void FPerfDogExtensionModule::PostIntValue(const FString& Category, const FString& Key, int32 Value)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->PostValueI(Category, Key, Value);
	}
}

void FPerfDogExtensionModule::PostIntValue(const FString& Category, const FString& Key, int32 Value1, int32 Value2)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->PostValueI(Category, Key, Value1, Value2);
	}
}

void FPerfDogExtensionModule::PostIntValue(const FString& Category, const FString& Key, int32 Value1, int32 Value2, int32 Value3)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->PostValueI(Category, Key, Value1, Value2, Value3);
	}
}

void FPerfDogExtensionModule::PostStringValue(const FString& Category, const FString& Key, const FString& Value)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->PostValueS(Category, Key, Value);
	}
}

void FPerfDogExtensionModule::SetLabel(const FString& LabelName)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->SetLabel(LabelName);
	}
}

void FPerfDogExtensionModule::AddNote(const FString& NoteText)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->AddNote(NoteText);
	}
}

void FPerfDogExtensionModule::DeepMark(const FString& Name)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->DeepMark(Name);
	}
}

void FPerfDogExtensionModule::DeepCounter(const FString& Name, float Value)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->DeepCounter(Name, Value);
	}
}

void FPerfDogExtensionModule::DeepPush(const FString& Name)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->DeepPush(Name);
	}
}

void FPerfDogExtensionModule::DeepPop(const FString& Name)
{
	if (ExtensionInstance)
	{
		ExtensionInstance->DeepPop(Name);
	}
}

IMPLEMENT_MODULE(FPerfDogExtensionModule, PerfDogExtension)