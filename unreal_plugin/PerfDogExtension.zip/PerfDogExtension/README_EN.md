# PerfDog Extension for Unreal Engine

PerfDog performance testing Unreal Engine plugin extension, supporting custom performance data reporting to PerfDog.

## Version Compatibility

- **Unreal Engine Version**: 4.24 and above (including all UE5 series)
- **Platform Support**: Windows, Mac, iOS, Android

## Features

- ✅ Custom performance data reporting (float, integer, string)
- ✅ Scene tagging and annotation functionality
- ✅ Complete Blueprint interface support
- ✅ C++ interface support
- ✅ Multi-value data reporting (supports reporting 1-3 values simultaneously)

## Setup Instructions

1. Copy the plugin to your project's `Plugins/` directory
2. Regenerate project files and build
3. Ensure that the `PerfDogExtension` plugin is enabled in your project's `Plugins` settings
4. **For C++ projects only**: Add `"PerfDogExtension"` module dependency in your project's `Build.cs` file
5. Call the enable interface when the game starts

## Usage

### Basic Usage

#### C++ Method
**First, add module dependency in your project's Build.cs:**
```csharp
// YourProject.Build.cs
PublicDependencyModuleNames.AddRange(new string[] { 
    "Core", "CoreUObject", "Engine",
    "PerfDogExtension"  // Add PerfDog module dependency
});
```

**Then use in your code:**
```cpp
#include "PerfDogExtensionBlueprintLibrary.h"

// Enable PerfDog extension
int32 Result = UPerfDogExtensionBlueprintLibrary::EnablePerfDogExtension();

// Report performance data
UPerfDogExtensionBlueprintLibrary::PostFloatValue("FPS", "Current", 60.0f);
UPerfDogExtensionBlueprintLibrary::PostIntValue("Memory", "Used", 1024);
UPerfDogExtensionBlueprintLibrary::PostStringValue("Status", "Level", "Loading");

// Scene tagging
UPerfDogExtensionBlueprintLibrary::SetLabel("MainMenu");

// Add annotation
UPerfDogExtensionBlueprintLibrary::AddNote("Boss Battle Start");
```

#### Blueprint Method
Use the following nodes in Blueprint:
- `Enable PerfDog Extension`
- `Post Float Value`, `Post Int Value`, `Post String Value`
- `Set Label`, `Add Note`

### Check Connection Status

```cpp
bool IsConnected = UPerfDogExtensionBlueprintLibrary::IsTestStarted();
```

## API Reference

### Management API

```cpp
EnablePerfDogExtension()    // Enable PerfDog functionality, returns 0 on success
IsTestStarted()            // Check connection status
```

### Data Reporting API

#### Float Values
```cpp
PostFloatValue(FString Category, FString Key, float Value)
PostFloatValue2(FString Category, FString Key, float Value1, float Value2)
PostFloatValue3(FString Category, FString Key, float Value1, float Value2, float Value3)
```

#### Integer Values
```cpp
PostIntValue(FString Category, FString Key, int32 Value)
PostIntValue2(FString Category, FString Key, int32 Value1, int32 Value2)
PostIntValue3(FString Category, FString Key, int32 Value1, int32 Value2, int32 Value3)
```

#### String Values
```cpp
PostStringValue(FString Category, FString Key, FString Value)
```

### Scene Management API

```cpp
SetLabel(FString Name)      // Set scene label
AddNote(FString Name)       // Add annotation
```

## Sample Project

See `Examples/PerfDogExampleActor.h` and `Examples/PerfDogUsageExample.cpp` for complete usage examples.

### Sample Actor Features
- Automatically reports FPS, memory, CPU, GPU data
- Configurable reporting frequency
- Includes both Blueprint and C++ implementations

## Troubleshooting

### Common Issues

1. **Build Errors**: Ensure Unreal Engine version is 4.24 or higher
2. **Network Connection Failed**: Check if port 53000 is occupied
3. **Data Not Reporting**: Confirm PerfDog client is connected and test has started
4. **Plugin Not Loading**: Check if plugin is correctly placed in Plugins directory

### Debug Information

The plugin displays detailed debug information in UE output log, including:
- Server startup status
- Client connection/disconnection
- Data sending status
- Error messages

### Log Viewing
In UE Editor, view PerfDog related logs through `Window > Developer Tools > Output Log`.

## Deployment Guide

### Plugin Structure
```
PerfDogExtension/
├── Source/                    # Source code
│   └── PerfDogExtension/
│       ├── Private/          # Private implementation
│       └── Public/           # Public interface
├── Content/                  # Content resources
├── Examples/                 # Example code
├── Resources/                # Plugin resources
├── README.md                 # Chinese documentation
├── README_EN.md              # English documentation
├── COMPATIBILITY.md          # Compatibility notes
└── PerfDogExtension.uplugin  # Plugin descriptor file
```

### Platform Features
- **Windows**: Uses high-precision performance counters
- **Mac/iOS**: Uses mach_absolute_time for precise timing
- **Android**: Uses standard POSIX time API

## License

MIT License

## Contact

- Official Website: https://perfdog.qq.com
- Email: PerfDog@tencent.com
- International Website: https://perfdog.wetest.net/
- International Email: perfdog_net@tencent.com

---

**Make your Unreal Engine performance analysis simpler and more flexible!** 