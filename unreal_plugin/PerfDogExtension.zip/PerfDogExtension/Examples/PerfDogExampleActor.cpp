// Copyright Epic Games, Inc. All Rights Reserved.

#include "PerfDogExampleActor.h"
#include "PerfDogExtensionBlueprintLibrary.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "HAL/PlatformMemory.h"
#include "Misc/DateTime.h"

APerfDogExampleActor::APerfDogExampleActor()
{
	PrimaryActorTick.bCanEverTick = true;
	ReportTimer = 0.0f;
}

void APerfDogExampleActor::BeginPlay()
{
	Super::BeginPlay();
	
	// 启用PerfDog扩展
	EnablePerfDog();
}

void APerfDogExampleActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	
	// 定期上报性能数据
	ReportTimer += DeltaTime;
	if (ReportTimer >= ReportInterval)
	{
		ReportPerformanceData();
		ReportTimer = 0.0f;
	}
}

void APerfDogExampleActor::EnablePerfDog()
{
	int32 Result = UPerfDogExtensionBlueprintLibrary::EnablePerfDogExtension();
	if (Result == 0)
	{
		UE_LOG(LogTemp, Log, TEXT("PerfDog扩展启用成功"));
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("PerfDog扩展启用失败，错误码: %d"), Result);
	}
}

void APerfDogExampleActor::ReportPerformanceData()
{
	if (!UPerfDogExtensionBlueprintLibrary::IsTestStarted())
	{
		return;
	}
	
	// 上报FPS
	float FPS = 1.0f / GetWorld()->GetDeltaSeconds();
	UPerfDogExtensionBlueprintLibrary::PostFloatValue(TEXT("Performance"), TEXT("FPS"), FPS);
	
	// 上报内存使用（示例数据）
	float MemoryUsage = FPlatformMemory::GetStats().UsedPhysical / (1024.0f * 1024.0f); // MB
	UPerfDogExtensionBlueprintLibrary::PostFloatValue(TEXT("Performance"), TEXT("MemoryMB"), MemoryUsage);
	
	// 上报CPU使用率（示例数据）
	float CPUUsage = FMath::RandRange(20.0f, 80.0f);
	UPerfDogExtensionBlueprintLibrary::PostFloatValue(TEXT("Performance"), TEXT("CPUUsage"), CPUUsage);
	
	// 上报GPU使用率（示例数据）
	float GPUUsage = FMath::RandRange(30.0f, 90.0f);
	UPerfDogExtensionBlueprintLibrary::PostFloatValue(TEXT("Performance"), TEXT("GPUUsage"), GPUUsage);
	
	// 上报玩家位置
	FVector PlayerLocation = GetActorLocation();
	UPerfDogExtensionBlueprintLibrary::PostFloatValue3(TEXT("Player"), TEXT("Position"), 
		PlayerLocation.X, PlayerLocation.Y, PlayerLocation.Z);
	
	// 上报游戏状态
	UPerfDogExtensionBlueprintLibrary::PostStringValue(TEXT("Game"), TEXT("State"), TEXT("Playing"));
}

void APerfDogExampleActor::SetSceneLabel(const FString& SceneName)
{
	UPerfDogExtensionBlueprintLibrary::SetLabel(SceneName);
	UE_LOG(LogTemp, Log, TEXT("设置场景标签: %s"), *SceneName);
}

void APerfDogExampleActor::AddPerformanceNote(const FString& Note)
{
	UPerfDogExtensionBlueprintLibrary::AddNote(Note);
	UE_LOG(LogTemp, Log, TEXT("添加性能注释: %s"), *Note);
}

void APerfDogExampleActor::ReportGameData(const FString& Category, const FString& Key, float Value)
{
	if (bPerfDogEnabled)
	{
		FPerfDogExtensionModule::PostFloatValue(Category, Key, Value);
		UE_LOG(LogTemp, Verbose, TEXT("Reported game data: %s.%s = %.2f"), *Category, *Key, Value);
	}
}

void APerfDogExampleActor::ReportPlayerPosition(const FVector& Position)
{
	if (bPerfDogEnabled)
	{
		FPerfDogExtensionModule::PostFloatValue(TEXT("Player"), TEXT("Position"), Position.X, Position.Y, Position.Z);
		UE_LOG(LogTemp, Verbose, TEXT("Reported player position: (%.2f, %.2f, %.2f)"), Position.X, Position.Y, Position.Z);
	}
}

void APerfDogExampleActor::ReportGameState(const FString& State)
{
	if (bPerfDogEnabled)
	{
		FPerfDogExtensionModule::PostStringValue(TEXT("Game"), TEXT("State"), State);
		UE_LOG(LogTemp, Log, TEXT("Reported game state: %s"), *State);
	}
} 