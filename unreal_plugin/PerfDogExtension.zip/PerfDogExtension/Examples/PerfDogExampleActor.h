// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "PerfDogExtensionBlueprintLibrary.h"
#include "PerfDogExampleActor.generated.h"

/**
 * PerfDog使用示例Actor
 * 演示如何在游戏中使用PerfDog扩展进行性能监控
 */
UCLASS()
class PERFDOGEXTENSION_API APerfDogExampleActor : public AActor
{
	GENERATED_BODY()
	
public:	
	APerfDogExampleActor();

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	// 启用PerfDog扩展
	UFUNCTION(BlueprintCallable, Category = "PerfDog Example")
	void EnablePerfDog();

	// 上报性能数据示例
	UFUNCTION(BlueprintCallable, Category = "PerfDog Example")
	void ReportPerformanceData();

	// 设置场景标签
	UFUNCTION(BlueprintCallable, Category = "PerfDog Example")
	void SetSceneLabel(const FString& SceneName);

	// 添加性能注释
	UFUNCTION(BlueprintCallable, Category = "PerfDog Example")
	void AddPerformanceNote(const FString& Note);

private:
	// 性能数据上报计时器
	float ReportTimer;
	
	// 上报间隔（秒）
	UPROPERTY(EditAnywhere, Category = "PerfDog Example")
	float ReportInterval = 1.0f;
}; 