// PerfDog Extension 使用示例
// 演示如何在Unreal Engine项目中使用PerfDog进行性能监控

#include "PerfDogExtension.h"
#include "Engine/Engine.h"
#include "HAL/PlatformMemory.h"

// 示例1: 在GameMode中集成PerfDog监控
class AMyGameMode : public AGameModeBase
{
protected:
    virtual void BeginPlay() override
    {
        Super::BeginPlay();
        
        // 启用PerfDog扩展
        int32 Result = FPerfDogExtensionModule::EnablePerfDogExtension();
        if (Result == 0)
        {
            UE_LOG(LogTemp, Log, TEXT("PerfDog Extension enabled successfully"));
            
            // 设置初始场景标签
            FPerfDogExtensionModule::SetLabel(TEXT("MainMenu"));
        }
        else
        {
            UE_LOG(LogTemp, Warning, TEXT("Failed to enable PerfDog Extension, error code: %d"), Result);
        }
    }
    
    virtual void Tick(float DeltaTime) override
    {
        Super::Tick(DeltaTime);
        
        // 定期上报性能数据
        static float AccumulatedTime = 0.0f;
        AccumulatedTime += DeltaTime;
        
        if (AccumulatedTime >= 1.0f) // 每秒上报一次
        {
            // 上报FPS
            float FPS = 1.0f / DeltaTime;
            FPerfDogExtensionModule::PostFloatValue(TEXT("Performance"), TEXT("FPS"), FPS);
            
            // 上报内存使用
            float MemoryMB = FPlatformMemory::GetStats().UsedPhysical / (1024.0f * 1024.0f);
            FPerfDogExtensionModule::PostFloatValue(TEXT("Performance"), TEXT("Memory"), MemoryMB);
            
            // 上报CPU使用率 (示例值，实际应该从系统获取)
            float CPUUsage = 45.0f;
            FPerfDogExtensionModule::PostFloatValue(TEXT("Performance"), TEXT("CPU"), CPUUsage);
            
            // 上报GPU使用率 (示例值，实际应该从渲染系统获取)
            float GPUUsage = 70.0f;
            FPerfDogExtensionModule::PostFloatValue(TEXT("Performance"), TEXT("GPU"), GPUUsage);
            
            AccumulatedTime = 0.0f;
        }
    }
};

// 示例2: 在Actor中监控特定事件
class APerfDogMonitoredActor : public AActor
{
protected:
    virtual void BeginPlay() override
    {
        Super::BeginPlay();
        
        // 设置场景标签
        FPerfDogExtensionModule::SetLabel(TEXT("ActorSpawned"));
        
        // 上报Actor创建事件
        FPerfDogExtensionModule::AddNote(TEXT("Actor spawned successfully"));
    }
    
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override
    {
        Super::EndPlay(EndPlayReason);
        
        // 上报Actor销毁事件
        FPerfDogExtensionModule::AddNote(TEXT("Actor destroyed"));
    }
    
    // 示例：监控玩家输入事件
    void OnPlayerInput()
    {
        // 上报玩家输入事件
        FPerfDogExtensionModule::PostStringValue(TEXT("GameEvents"), TEXT("PlayerInput"), TEXT("ButtonPressed"));
        
        // 上报输入响应时间
        FPerfDogExtensionModule::PostFloatValue(TEXT("Performance"), TEXT("InputLatency"), 16.0f);
    }
    
    // 示例：监控游戏状态变化
    void OnGameStateChanged(const FString& NewState)
    {
        // 设置新的场景标签
        FPerfDogExtensionModule::SetLabel(NewState);
        
        // 上报状态变化
        FPerfDogExtensionModule::PostStringValue(TEXT("GameState"), TEXT("CurrentState"), NewState);
    }
};

// 示例3: 监控网络性能
class ANetworkMonitoredActor : public AActor
{
public:
    void ReportNetworkLatency(float Latency)
    {
        FPerfDogExtensionModule::PostFloatValue(TEXT("Network"), TEXT("Latency"), Latency);
    }
    
    void ReportNetworkPacketLoss(float PacketLossRate)
    {
        FPerfDogExtensionModule::PostFloatValue(TEXT("Network"), TEXT("PacketLoss"), PacketLossRate);
    }
    
    void ReportNetworkBandwidth(float BandwidthMbps)
    {
        FPerfDogExtensionModule::PostFloatValue(TEXT("Network"), TEXT("Bandwidth"), BandwidthMbps);
    }
};

// 示例4: 监控移动设备特定指标
class AMobilePerformanceMonitor : public AActor
{
public:
    void ReportBatteryLevel(float BatteryLevel)
    {
        FPerfDogExtensionModule::PostFloatValue(TEXT("Mobile"), TEXT("Battery"), BatteryLevel);
    }
    
    void ReportTemperature(float Temperature)
    {
        FPerfDogExtensionModule::PostFloatValue(TEXT("Mobile"), TEXT("Temperature"), Temperature);
    }
    
    void ReportDeviceInfo(const FString& DeviceModel, const FString& OSVersion)
    {
        FPerfDogExtensionModule::PostStringValue(TEXT("Device"), TEXT("Model"), DeviceModel);
        FPerfDogExtensionModule::PostStringValue(TEXT("Device"), TEXT("OS"), OSVersion);
    }
};

// 示例5: 在蓝图中使用的函数
// 这些函数可以在蓝图中直接调用

// 启用PerfDog监控
UFUNCTION(BlueprintCallable, Category = "PerfDog")
void EnablePerfDogMonitoring()
{
    int32 Result = FPerfDogExtensionModule::EnablePerfDogExtension();
    if (Result == 0)
    {
        UE_LOG(LogTemp, Log, TEXT("PerfDog monitoring enabled from Blueprint"));
    }
}

// 上报游戏分数
UFUNCTION(BlueprintCallable, Category = "PerfDog")
void ReportGameScore(int32 Score)
{
    FPerfDogExtensionModule::PostIntValue(TEXT("Game"), TEXT("Score"), Score);
}

// 上报玩家位置
UFUNCTION(BlueprintCallable, Category = "PerfDog")
void ReportPlayerLocation(float X, float Y, float Z)
{
    FPerfDogExtensionModule::PostFloatValue(TEXT("Player"), TEXT("Location"), X, Y, Z);
}

// 设置游戏场景
UFUNCTION(BlueprintCallable, Category = "PerfDog")
void SetGameScene(const FString& SceneName)
{
    FPerfDogExtensionModule::SetLabel(SceneName);
}

// 添加游戏事件注释
UFUNCTION(BlueprintCallable, Category = "PerfDog")
void AddGameEventNote(const FString& EventDescription)
{
    FPerfDogExtensionModule::AddNote(EventDescription);
}

// 使用建议：
// 1. 在游戏开始时调用 EnablePerfDogExtension() 启用监控
// 2. 使用 SetLabel() 标记不同的游戏场景
// 3. 使用 PostFloatValue() 上报性能数据
// 4. 使用 PostIntValue() 上报游戏数据
// 5. 使用 PostStringValue() 上报状态信息
// 6. 使用 AddNote() 添加重要事件的注释
// 7. 在关键性能点使用标签和注释进行标记 