# PerfDog Extension 示例代码

这个目录包含了PerfDog扩展插件的使用示例代码。

## 文件说明

### PerfDogExampleActor.h / PerfDogExampleActor.cpp
一个完整的示例Actor，演示如何在游戏中使用PerfDog进行性能监控。

**功能特性：**
- 自动启用PerfDog监控
- 定期上报FPS和内存使用情况
- 提供完整的蓝图接口
- 支持自定义数据上报

**使用方法：**
1. 将这两个文件复制到你的项目的Source目录中
2. 重新编译项目
3. 在场景中放置此Actor
4. 在蓝图中调用相关函数

### PerfDogUsageExample.cpp
包含多种使用场景的代码示例，包括：
- GameMode集成示例
- Actor监控示例
- 网络性能监控示例
- 移动设备特定指标监控示例
- 蓝图调用示例

## 快速开始

### 1. 复制示例文件
将`PerfDogExampleActor.h`和`PerfDogExampleActor.cpp`复制到你的项目的Source目录中。

### 2. 添加到项目
在你的项目的Build.cs文件中添加模块依赖：
```cpp
PublicDependencyModuleNames.AddRange(
    new string[]
    {
        "PerfDogExtension"
    }
);
```

### 3. 在场景中使用
1. 在场景中放置`PerfDogExampleActor`
2. 在蓝图中调用`Enable PerfDog Monitoring`
3. 根据需要调用其他监控函数

### 4. 自定义使用
参考`PerfDogUsageExample.cpp`中的示例代码，根据你的项目需求进行定制。

## 注意事项

- 示例代码仅供学习和参考使用
- 在实际项目中，请根据具体需求进行修改和优化
- 确保PerfDog客户端已连接并开始测试

## 更多示例

更多使用示例请参考主目录下的README.md文件。 