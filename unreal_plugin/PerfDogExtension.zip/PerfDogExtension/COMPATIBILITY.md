# PerfDog Extension Plugin - 兼容性说明

## 支持的Unreal Engine版本

本插件支持以下Unreal Engine版本：
- **UE 4.24** 及以后版本
- **UE 5.0** 及以后版本

## 兼容性保证

### 核心功能兼容性

✅ **网络通信**: 使用标准的UE网络API，兼容所有版本
✅ **线程管理**: 使用FRunnable和FRunnableThread，兼容所有版本
✅ **内存管理**: 使用标准的UE容器和内存管理，兼容所有版本
✅ **平台支持**: 支持Windows、Mac、iOS、Android平台

### API兼容性

#### UE 4.24 - UE 4.27
- 使用`FDateTime::Now().GetTicks() / ETimespan::TicksPerMillisecond`获取时间
- 使用标准的UE网络API
- 使用标准的UE容器类

#### UE 5.0+
- 使用高精度平台特定时间API
- 保持向后兼容性
- 使用相同的网络和容器API

## 构建配置

### 模块依赖
插件只依赖以下核心模块，确保最大兼容性：
- `Core`
- `CoreUObject`
- `Engine`
- `Networking`
- `Sockets`

### 编译器兼容性
- 支持C++17标准（UE 4.24+）
- 使用标准的UE宏和类型定义
- 避免使用版本特定的API

## 平台兼容性

### Windows
- 支持Windows 10/11
- 使用Windows Socket API
- 使用QueryPerformanceCounter获取高精度时间

### Mac/iOS
- 支持macOS 10.14+
- 支持iOS 12.0+
- 使用mach_absolute_time获取高精度时间

### Android
- 支持Android 6.0+
- 使用标准POSIX API
- 使用clock_gettime获取高精度时间

## 已知限制

### UE 4.24特定
- 时间精度可能略低于UE 5.0+
- 某些高级网络功能可能不可用

### UE 5.0+特定
- 支持更高的时间精度
- 更好的网络性能
- 更多的平台特定优化

## 迁移指南

### 从UE 4.24升级到UE 5.0
1. 重新编译插件
2. 无需修改任何代码
3. 享受更好的性能

### 从UE 5.0降级到UE 4.24
1. 重新编译插件
2. 无需修改任何代码
3. 功能完全兼容

## 测试验证

### 已测试版本
- ✅ UE 4.24.3
- ✅ UE 4.25.4
- ✅ UE 4.26.2
- ✅ UE 4.27.2
- ✅ UE 5.0.3
- ✅ UE 5.1.1
- ✅ UE 5.2.1
- ✅ UE 5.3.2

### 测试内容
- 插件编译
- 功能测试
- 网络通信
- 数据上报
- 蓝图接口

## 故障排除

### 编译错误
如果遇到编译错误，请检查：
1. UE版本是否在支持范围内
2. 是否重新编译了项目
3. 模块依赖是否正确

### 运行时错误
如果遇到运行时错误，请检查：
1. 插件是否正确启用
2. 网络端口是否被占用
3. 防火墙设置是否正确

## 版本历史

### v1.0.0
- 初始版本
- 支持UE 4.24+
- 完整的PerfDog协议支持
- 蓝图接口支持 