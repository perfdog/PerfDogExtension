# PerfDog Extension for Unreal Engine

PerfDog性能测试Unreal Engine插件扩展，支持自定义性能数据上报到PerfDog。

## 版本兼容性

- **Unreal Engine版本**: 4.24 及以上版本（包括UE5全系列）
- **平台支持**: Windows、Mac、iOS、Android

## 功能特性

- ✅ 自定义性能数据上报（浮点数、整数、字符串）
- ✅ 场景标记和批注功能
- ✅ 完整的蓝图接口支持
- ✅ C++接口支持
- ✅ 多值数据上报（支持1-3个值同时上报）

## 启用说明

1. 将插件复制到项目的 `Plugins/` 目录
2. 重新生成项目文件并编译
3. 确保在项目的 `Plugins` 设置中启用 `PerfDogExtension` 插件
4. **仅C++项目需要**：在项目的`Build.cs`文件中添加`"PerfDogExtension"`模块依赖
5. 在游戏开始时调用启用接口

## 使用方法

### 基本使用

#### C++方式
**首先在项目Build.cs中添加模块依赖：**
```csharp
// YourProject.Build.cs
PublicDependencyModuleNames.AddRange(new string[] { 
    "Core", "CoreUObject", "Engine",
    "PerfDogExtension"  // 添加PerfDog模块依赖
});
```

**然后在代码中使用：**
```cpp
#include "PerfDogExtensionBlueprintLibrary.h"

// 启用PerfDog扩展
int32 Result = UPerfDogExtensionBlueprintLibrary::EnablePerfDogExtension();

// 上报性能数据
UPerfDogExtensionBlueprintLibrary::PostFloatValue("FPS", "Current", 60.0f);
UPerfDogExtensionBlueprintLibrary::PostIntValue("Memory", "Used", 1024);
UPerfDogExtensionBlueprintLibrary::PostStringValue("Status", "Level", "Loading");

// 场景标记
UPerfDogExtensionBlueprintLibrary::SetLabel("MainMenu");

// 添加批注
UPerfDogExtensionBlueprintLibrary::AddNote("Boss Battle Start");
```

#### 蓝图方式
在蓝图中使用以下节点：
- `Enable PerfDog Extension`
- `Post Float Value`、`Post Int Value`、`Post String Value`
- `Set Label`、`Add Note`

### 检查连接状态

```cpp
bool IsConnected = UPerfDogExtensionBlueprintLibrary::IsTestStarted();
```

## API参考

### 管理API

```cpp
EnablePerfDogExtension()    // 启用PerfDog功能，返回0表示成功
IsTestStarted()            // 检查连接状态
```

### 数据上报API

#### 浮点数值
```cpp
PostFloatValue(FString Category, FString Key, float Value)
PostFloatValue2(FString Category, FString Key, float Value1, float Value2)
PostFloatValue3(FString Category, FString Key, float Value1, float Value2, float Value3)
```

#### 整数值
```cpp
PostIntValue(FString Category, FString Key, int32 Value)
PostIntValue2(FString Category, FString Key, int32 Value1, int32 Value2)
PostIntValue3(FString Category, FString Key, int32 Value1, int32 Value2, int32 Value3)
```

#### 字符串值
```cpp
PostStringValue(FString Category, FString Key, FString Value)
```

### 场景管理API

```cpp
SetLabel(FString Name)      // 设置场景标签
AddNote(FString Name)       // 添加批注
```

## 示例项目

查看`Examples/PerfDogExampleActor.h`和`Examples/PerfDogUsageExample.cpp`了解完整的使用示例。

### 示例Actor特性
- 自动上报FPS、内存、CPU、GPU等数据
- 可配置上报频率
- 包含蓝图和C++两种实现方式

## 故障排除

### 常见问题

1. **编译错误**: 确保Unreal Engine版本为4.24或更高
2. **网络连接失败**: 检查端口53000是否被占用
3. **数据未上报**: 确认PerfDog客户端已连接并开始测试
4. **插件未加载**: 检查插件是否正确放置在Plugins目录

### 调试信息

插件会在UE输出日志中显示详细的调试信息，包括：
- 服务器启动状态
- 客户端连接/断开
- 数据发送状态
- 错误信息

### 日志查看
在UE编辑器中通过`Window > Developer Tools > Output Log`查看PerfDog相关日志。

## 部署说明

### 插件结构
```
PerfDogExtension/
├── Source/                    # 源代码
│   └── PerfDogExtension/
│       ├── Private/          # 私有实现
│       └── Public/           # 公共接口
├── Content/                  # 内容资源
├── Examples/                 # 示例代码
├── Resources/                # 插件资源
├── README.md                 # 中文说明文档
├── README_EN.md              # 英文说明文档
├── COMPATIBILITY.md          # 兼容性说明
└── PerfDogExtension.uplugin  # 插件描述文件
```

### 平台特性
- **Windows**: 使用高精度性能计数器
- **Mac/iOS**: 使用mach_absolute_time获取精确时间
- **Android**: 使用标准POSIX时间API

## 许可证

MIT License

## 联系方式

- 官方网站: https://perfdog.qq.com
- 邮箱: PerfDog@tencent.com
- 国际官网: https://perfdog.wetest.net/
- 国际邮箱: perfdog_net@tencent.com

---

**让您的Unreal Engine性能分析更简单、更灵活！** 